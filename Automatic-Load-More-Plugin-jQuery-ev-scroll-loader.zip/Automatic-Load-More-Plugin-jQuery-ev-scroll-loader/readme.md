# Ensemble Video jQuery Scroll Loader Plugin

jQuery plugin to load more content when user scrolls to bottom of content area.

## Getting Started
Download the [production version][min] or the [development version][max].

[min]: https://raw.github.com/jmpease/ev-scroll-loader/master/dist/ev-scroll-loader.min.js
[max]: https://raw.github.com/jmpease/ev-scroll-loader/master/dist/ev-scroll-loader.js

In your web page:

```html
<script src="jquery.js"></script>
<script src="dist/ev-scroll-loader.min.js"></script>
<script>
jQuery(function($) {
  $('.scrollMe').evScrollLoader({
    height: 400,
    callback: function() {
      loadMoreStuff();
    }
  });
});
</script>
```

## Documentation
_(Coming soon)_

## Examples
_(Coming soon)_

## Release History
_(Nothing yet)_
